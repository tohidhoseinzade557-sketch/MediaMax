plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android { namespace="com.mediamax.app"; compileSdk=36
 defaultConfig { applicationId="com.mediamax.app"; minSdk=26; targetSdk=36; versionCode=1; versionName="1.0" }
 buildTypes { release { isMinifyEnabled=false; proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"),"proguard-rules.pro") } }
 compileOptions { sourceCompatibility=JavaVersion.VERSION_17; targetCompatibility=JavaVersion.VERSION_17 }
 kotlinOptions { jvmTarget="17" }
}
dependencies {
 implementation("androidx.core:core-ktx:1.17.0")
 implementation("androidx.activity:activity-compose:1.11.0")
 implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.9.3")
 implementation("androidx.webkit:webkit:1.14.0")
 implementation("com.squareup.okhttp3:okhttp:4.12.0")
}

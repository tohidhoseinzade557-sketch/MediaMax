package com.mediamax.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.webkit.WebViewAssetLoader
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.asRequestBody
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.net.URL
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec
import android.app.DownloadManager
import java.util.Base64

class MainActivity : ComponentActivity() {
    private lateinit var web: WebView
    private lateinit var loader: WebViewAssetLoader

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = false
            settings.allowContentAccess = true
            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(view: WebView, url: String) = loader.shouldInterceptRequest(Uri.parse(url))
            }
            webChromeClient = WebChromeClient()
            addJavascriptInterface(NativeBridge(this@MainActivity, this), "MediaMaxAndroid")
        }
        setContentView(web)
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html")
        handleIntent(intent)
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { if (web.canGoBack()) web.goBack() else finish() }
        })
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent); setIntent(intent); handleIntent(intent)
    }

    private fun handleIntent(intent: Intent?) {
        if (intent?.action != Intent.ACTION_SEND) return
        val text = intent.getStringExtra(Intent.EXTRA_TEXT)
        val stream = if (android.os.Build.VERSION.SDK_INT >= 33)
            intent.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
        else @Suppress("DEPRECATION") intent.getParcelableExtra(Intent.EXTRA_STREAM)
        when {
            !text.isNullOrBlank() -> sendUrlToWeb(text.trim())
            stream != null -> sendUriToWeb(stream)
        }
    }

    private fun sendUrlToWeb(value: String) {
        val q = JSONObject.quote(value)
        web.post { web.evaluateJavascript("window.MediaMaxReceiveUrl($q);", null) }
    }
    private fun sendUriToWeb(uri: Uri) {
        val q = JSONObject.quote(uri.toString())
        web.post { web.evaluateJavascript("window.MediaMaxReceiveUrl($q); window.MediaMaxReceiveMedia && window.MediaMaxReceiveMedia($q);", null) }
    }

    class NativeBridge(private val context: Context, private val web: WebView) {
        private val client = OkHttpClient()

        @JavascriptInterface
        fun downloadDirect(url: String): Long {
            val name = try { URL(url).path.substringAfterLast('/').ifBlank { "mediamax_file" } } catch (_: Exception) { "mediamax_file" }
            val request = DownloadManager.Request(Uri.parse(url))
                .setTitle(name).setDescription("MediaMax")
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setAllowedOverMetered(true).setAllowedOverRoaming(true)
                .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "MediaMax/$name")
            return (context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(request)
        }

        @JavascriptInterface
        fun openUrl(url: String) { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }

        @JavascriptInterface
        fun saveAcrConfig(host: String, key: String, secret: String) {
            context.getSharedPreferences("acr", Context.MODE_PRIVATE).edit()
                .putString("host", host.trim().removePrefix("https://").removeSuffix("/"))
                .putString("key", key.trim()).putString("secret", secret.trim()).apply()
        }

        @JavascriptInterface
        fun recognizeSharedUri(uriString: String) {
            Thread {
                try {
                    val uri = Uri.parse(uriString)
                    val prefs = context.getSharedPreferences("acr", Context.MODE_PRIVATE)
                    val host = prefs.getString("host", "") ?: ""
                    val key = prefs.getString("key", "") ?: ""
                    val secret = prefs.getString("secret", "") ?: ""
                    if (host.isBlank() || key.isBlank() || secret.isBlank()) {
                        callback("ERROR", "ابتدا Host، Access Key و Access Secret سرویس ACRCloud را در تنظیمات وارد کنید.")
                        return@Thread
                    }
                    val tmp = File.createTempFile("mediamax_", ".mp4", context.cacheDir)
                    context.contentResolver.openInputStream(uri)?.use { input -> FileOutputStream(tmp).use { out -> input.copyTo(out) } }
                        ?: throw IllegalStateException("فایل قابل خواندن نیست")
                    if (tmp.length() > 5L * 1024 * 1024) throw IllegalStateException("حجم نمونه بیشتر از 5MB است؛ یک کلیپ کوتاه‌تر انتخاب کنید.")
                    val result = acrIdentify(host, key, secret, tmp)
                    tmp.delete()
                    val status = result.optJSONObject("status")
                    val metadata = result.optJSONObject("metadata")
                    val music = metadata?.optJSONArray("music")
                    if (status?.optInt("code", -1) == 0 && music != null && music.length() > 0) {
                        val m = music.getJSONObject(0)
                        val title = m.optString("title", "آهنگ شناسایی شد")
                        val artists = m.optJSONArray("artists")?.let { a -> if (a.length()>0) a.getJSONObject(0).optString("name") else "" } ?: ""
                        callback("OK", if (artists.isBlank()) title else "$title — $artists")
                    } else callback("NONE", "آهنگی با اطمینان کافی پیدا نشد.")
                } catch (e: Exception) { callback("ERROR", e.message ?: "خطای شناسایی") }
            }.start()
        }

        private fun acrIdentify(host: String, key: String, secret: String, file: File): JSONObject {
            val uri = "/v1/identify"; val type = "audio"; val version = "1"; val timestamp = (System.currentTimeMillis()/1000).toString()
            val signText = "POST\n$uri\n$key\n$type\n$version\n$timestamp"
            val mac = Mac.getInstance("HmacSHA1")
            mac.init(SecretKeySpec(secret.toByteArray(Charsets.US_ASCII), "HmacSHA1"))
            val signature = Base64.getEncoder().encodeToString(mac.doFinal(signText.toByteArray(Charsets.US_ASCII)))
            val body = MultipartBody.Builder().setType(MultipartBody.FORM)
                .addFormDataPart("access_key", key)
                .addFormDataPart("sample_bytes", file.length().toString())
                .addFormDataPart("timestamp", timestamp)
                .addFormDataPart("signature", signature)
                .addFormDataPart("data_type", type)
                .addFormDataPart("signature_version", version)
                .addFormDataPart("sample", file.name, file.asRequestBody("video/mp4".toMediaType()))
                .build()
            val req = Request.Builder().url("https://$host$uri").post(body).build()
            client.newCall(req).execute().use { r ->
                if (!r.isSuccessful) throw IllegalStateException("ACRCloud HTTP ${r.code}")
                return JSONObject(r.body?.string() ?: "{}")
            }
        }

        private fun callback(type: String, message: String) {
            val t = JSONObject.quote(type); val m = JSONObject.quote(message)
            web.post { web.evaluateJavascript("window.MediaMaxMusicResult($t,$m);", null) }
        }
    }
}

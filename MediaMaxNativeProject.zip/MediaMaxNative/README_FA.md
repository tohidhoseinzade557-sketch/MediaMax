# MediaMax Native

این نسخه رابط HTML را داخل WebView واقعی Android اجرا می‌کند و Share Sheet اندروید را به برنامه وصل می‌کند.

## قابلیت متصل‌شده
- دریافت لینک با Share از Instagram و برنامه‌های دیگر از طریق ACTION_SEND/text/plain
- دریافت URI فایل با video/* و audio/*
- WebView + JavaScript bridge
- دانلود مستقیم واقعی با Android DownloadManager
- ذخیره در Downloads/MediaMax

## تشخیص آهنگ واقعی
برای تشخیص موسیقی باید یک سرویس fingerprint مانند ACRCloud به پروژه وصل شود. ACRCloud API/SDK و پایگاه موسیقی ارائه می‌کند، اما برای استفاده واقعی به حساب/کلید پروژه نیاز است. کلید را داخل HTML عمومی قرار نده؛ بهتر است در backend امن یا تنظیمات native نگهداری شود.
